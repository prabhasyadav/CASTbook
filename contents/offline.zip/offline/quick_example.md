## Quick example of offline CAST

**Sandhya** and **Iram** to do this.

This is one very simple example and linking to the model page for more detailed example.