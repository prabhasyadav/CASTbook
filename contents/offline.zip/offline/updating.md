## Updating OFFLINE CAST 

For updating the offline version of CAST : 

* `git pull` in the *CAST* folder
* run the command `python3 create_database.py` 
